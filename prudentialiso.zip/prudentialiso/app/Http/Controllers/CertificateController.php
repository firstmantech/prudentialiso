<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Certificate;

class CertificateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $certificates = Certificate::all();

        return view('certificates.index',compact('certificates'));        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('certificates.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        request()->validate([
            'certificate_no' => 'required',
            'company_name' => 'required',
            'address' => 'required',
            'scope' => 'required',
            'standard' => 'required|numeric',
            'issue_date' => 'required|email',
            'first_surv' => 'required',
            'second_surv' => 'required',
            'expiry_date' => 'required',
            'status' => 'required',
        ]);
        
        $certificate = new Certificate;
        $certificate->certificate_no = $request->certificate_no;
        $certificate->company_name = $request->company_name;
        $certificate->address = $request->address;
        $certificate->scope = $request->scope;
        $certificate->standard = $request->standard;
        $certificate->issue_date = $request->issue_date;
        $certificate->first_surv = $request->first_surv;
        $certificate->second_surv = $request->second_surv;
        $certificate->expiry_date = $request->expiry_date;
        $certificate->status = $request->status;
        $certificate->save();

        return redirect('/certificates')->with('success', 'Successfully Created the Certificate!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Certificate $certificate)
    {
        return view('certificates.show',compact('certificate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Certificate $certificate)
    {
        return view('certificates.edit',compact('certificate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        request()->validate([
            'certificate_no' => 'required',
            'company_name' => 'required',
            'address' => 'required',
            'scope' => 'required',
            'standard' => 'required',
            'issue_date' => 'required',
            'first_surv' => 'required',
            'second_surv' => 'required',
            'expiry_date' => 'required',
            'status' => 'required',
        ]);

        $certificate = Certificate::find($id);
        $certificate->certificate_no = $request->certificate_no;
        $certificate->company_name = $request->company_name;
        $certificate->address = $request->address;
        $certificate->scope = $request->scope;
        $certificate->standard = $request->standard;
        $certificate->issue_date = $request->issue_date;
        $certificate->first_surv = $request->first_surv;
        $certificate->second_surv = $request->second_surv;
        $certificate->expiry_date = $request->expiry_date;
        $certificate->status = $request->status;
        $certificate->save();


        return redirect('/certificates')->with('success', 'Successfully Modified the Certificate!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $id = Certificate::find( $id );
        $id ->delete();

        return redirect('/certificates')->with('success', 'Successfully Deleted the Certificate!');
    }
}
