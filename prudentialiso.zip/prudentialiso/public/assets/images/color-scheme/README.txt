Select one color scheme from css/color-scheme folder to use in the website and delete the remaining color scheme images folder.

