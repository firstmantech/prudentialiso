@extends('layouts.website')

@section('title', 'Partners')

@section('styles')

@stop

@section('content')

            

@stop

@section('scripts')

@stop