@extends('layouts.website')

@section('title', 'ISO 9001 Certification')

@section('styles')

@stop

@section('content')
    <!--================Banner Area =================-->
    <section class="banner_area">
        <div class="container">
            <div class="pull-left">
                <h3>Safety Training</h3>
            </div>
            <div class="pull-right">
                <a href="{{ url('/') }}">Home</a>
                <a>Safety Training</a>
            </div>
        </div>
    </section>
    <!--================End Banner Area =================-->
     

@stop

@section('scripts')

@stop