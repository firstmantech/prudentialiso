<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <a href="<?php echo e(url('certificates/create')); ?>" class="btn btn-info">Enter New Certificate</a>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">All Certificates</div>

                <div class="panel-body">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e($message); ?>

                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <table id="datatable" class="table table-striped table-bordered nowrap" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Certificate No</th>
                        <th>Company Name</th>
                        <th>Address One</th>
                        <th>Address Two</th>
                        <th>Scope</th>
                        <th>Standard</th>
                        <th>Issue Date</th> 
                        <th>1st Surv</th>
                        <th>2nd Surv</th>
                        <th>Expiry Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>


                    <tbody><?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($certificate->id); ?></td>
                        <td><?php echo e($certificate->certificate_no); ?></td>
                        <td><?php echo e($certificate->company_name); ?></td>
                        <td><?php echo e($certificate->address); ?></td>
                        <td><?php echo e($certificate->address_two); ?></td>
                        <td><?php echo e($certificate->scope); ?></td>
                        <td><?php echo e($certificate->standard); ?></td>
                        <td><?php echo e($certificate->issue_date); ?></td>
                        <td><?php echo e($certificate->first_surv); ?></td>
                        <td><?php echo e($certificate->second_surv); ?></td>
                        <td><?php echo e($certificate->expiry_date); ?></td>
                        <td><?php echo e($certificate->status); ?></td>
                        <td>
                            <a class="btn btn-sm btn-rounded btn-info" href="<?php echo e(route('certificates.edit',$certificate->id)); ?>">Edit</a>
                            <?php echo e(Form::open(array( 
                                'route' => array( 'certificates.destroy', $certificate->id ), 
                                'method' => 'delete', 
                                'style' => 'display:inline',
                                'onsubmit' => "return confirm('Are you sure you want to delete?')",
                            ))); ?>

                                 <?php echo e(Form::submit('Delete', array('class' => 'btn btn-sm btn-rounded btn-danger'))); ?>

                            <?php echo e(Form::close()); ?>

                        </td>                        
                    </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>