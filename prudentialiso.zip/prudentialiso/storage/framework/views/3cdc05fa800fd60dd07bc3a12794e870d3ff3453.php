<?php $__env->startSection('title', 'ISO 9001 Certification'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--================Banner Area =================-->
    <section class="banner_area">
        <div class="container">
            <div class="pull-left">
                <h3>Safety Training</h3>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a>Safety Training</a>
            </div>
        </div>
    </section>
    <!--================End Banner Area =================-->
     

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>