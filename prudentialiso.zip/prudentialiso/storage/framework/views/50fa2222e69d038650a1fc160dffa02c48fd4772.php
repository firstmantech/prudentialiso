<?php $__env->startSection('title', 'Certificate Search Results'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="subpage-header">
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 animate fadeInLeft">
				<?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					
					<table class="table table-bordered table-striped table-responsive">
						<thead>
							<tr>
								<td>Certificate Number</td>
								<td><?php echo e($certificate->certificate_no); ?></td>
							</tr>
							<tr>
								<td>Company Name :</td>
								<td><?php echo e($certificate->company_name); ?></td>
							</tr>
							<?php if(is_null($certificate->address_two)): ?>
							<tr>
								<td>Address</td>
								<td><?php echo e($certificate->address); ?></td>
							</tr>
							<?php else: ?>
							<tr>
								<td>Address One</td>
								<td><?php echo e($certificate->address); ?></td>
							</tr>
							<tr>
								<td>Address Two</td>
								<td><?php echo e($certificate->address_two); ?></td>
							</tr>
							<?php endif; ?>
							<tr>
								<td>Scope Of Business</td>
								<td><?php echo e($certificate->scope); ?></td>
							</tr>
							<tr>
								<td>Standard</td>
								<td><?php echo e($certificate->standard); ?></td>
							</tr>
							<tr>
								<td>Certificate Issues Date</td>
								<td><?php echo e($certificate->issue_date); ?></td>
							</tr>
							<tr>
								<td>1st Survielliance Date</td>
								<td><?php echo e($certificate->first_surv); ?></td>
							</tr>
							<tr>
								<td>2nd Survielliance Date</td>
								<td><?php echo e($certificate->second_surv); ?></td>
							</tr>
							<tr>
								<td>Valid Till</td>
								<td><?php echo e($certificate->expiry_date); ?></td>
							</tr>
							<tr>
								<td>Status</td>
								<td><?php echo e($certificate->status); ?></td>
							</tr>				
						</thead>
					</table>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<h1>Certificates not found!</h1>
				<?php endif; ?>
			</div>
		</div>					
	</div>
</section>
                                    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>