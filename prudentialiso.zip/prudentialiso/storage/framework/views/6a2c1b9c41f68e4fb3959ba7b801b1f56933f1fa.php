<?php $__env->startSection('title', 'Check Certificate Status'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        
        <!--================Tracking Button Area =================-->
        <section class="tracking_search_area">
            <div class="container">
                <div class="tracking_search_inner">
                    <h2 class="single_title">Check Your Certificate Status</h2>
                    <h5>Enter a Certificate number, and get status results.</h5>
                    <form name="subscribe_form" action="<?php echo e(route('search')); ?>" method="POST">
							 <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                      <input type="text" name="certificate" class="form-control" placeholder="Certificate Number">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="fa fa-circle-o-notch" aria-hidden="true"></i> Get Status</button>
                      </span>
                    </div><!-- /input-group -->
                  </form>
                </div>
            </div>
        </section>
        <!--================End Tracking Button Area =================-->
        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>