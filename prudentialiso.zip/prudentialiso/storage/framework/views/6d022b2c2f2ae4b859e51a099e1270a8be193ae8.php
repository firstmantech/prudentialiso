<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <!-- MAIN BANNER -->
            <section class="cd-hero">
                <ul class="cd-hero-slider autoplay">
                    <li class="selected">
                        <div class="cd-full-width">
                            <div class="container">
                                <h2>Why get ISO Certfication?</h2>
                                <p>ISO standards help to make the world a safer, cleaner and more efficient place</p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="cd-full-width">
                            <div class="container">
                                <h2>Benefits of ISO</h2>
                                <p>Increase in reputation and customer satisfaction due to certified assurance <br>about the quality, safety and reliability of products.</p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="cd-full-width">
                            <div class="container">
                                <h2>How to get ISO?</h2>
                                <p>Get an ISO certification with expert help by registering with us.</p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="cd-full-width">
                            <div class="container text-right">
                                <h2>What we do?</h2>
                                <p>We provide the best service with 10+ years of experience.</p>
                            </div>
                        </div>
                    </li>

                </ul>

                <div class="cd-slider-nav">
                    <nav class="container">
                        <span class="cd-marker item-1"></span>
                        
                        <ul>
                            <li class="selected"><a href="#0"><div class="slide-number">1</div>Why get ISO?</a></li>
                            <li><a href="#0"><div class="slide-number">2</div> Benefits of ISO</a></li>
                            <li><a href="#0"><div class="slide-number">3</div> How to get ISO?</a></li>
                            <li><a href="#0"><div class="slide-number">4</div> What we do?</a></li>
                        </ul>
                    </nav> 
                </div>
                
            </section> <!-- / MAIN BANNER -->
            
            
            <!-- WELCOME -->
            <section>
                <div class="container">
                    <div class="heading text-center animate bounceIn">
                        <h2>Our Services</h2>
                        <p>Consultation, Application drafting, Drafting of policy standards and Certificate issue.</p>
                    </div>
                    
                    <div class="height-50"></div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="text-box text-center animate fadeInUp">
                                <div class="bordered-thumb"><img src="<?php echo e(asset('assets/images/svg/Legal_Document.png')); ?>" alt=""></div>
                                <h4>Quality Policy</h4>
                                <p>The Certification offers ISO 22000 certification In India, ISO 9001 Certificate in Delhi, ISO 9001 Certification in India and much more certification courses in India sub continents.</p>
                            </div>
                        </div>
                        <div class="col-md-4 animate fadeInUp" data-delay="100">
                            <div class="text-box text-center">
                                <div class="bordered-thumb"><img src="<?php echo e(asset('assets/images/svg/Certificate.png')); ?>" alt=""></div>
                                <h4>Certification Benefits</h4>
                                <p>ISO 9001, ISO 14001, OHSAS 18001, ISO 22000, HACCP & CE MARKING, Tnv Certification offers ISO 22000 certification In India, Tnv, Tnv ISO, Tnv ISO India, ISO 9001 Certificate in Delhi, ISO 9001 Certification in India.</p>
                            </div> 
                        </div>
                        <div class="col-md-4 animate fadeInUp" data-delay="200">
                            <div class="text-box text-center">
                                <div class="bordered-thumb"><img src="<?php echo e(asset('assets/images/svg/Handshake.png')); ?>" alt=""></div>
                                <h4>UAF Accredited</h4>
                                <p>UAF (United Accreditation Foundation) is full member of International Accreditation Forum (IAF). The IAF is the world association of Conformity Assessment Accreditation</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- / WELCOME -->            
            
            <!-- WELCOME -->
            <section class="bg-blue">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 animate fadeInLeft">
                            <h2>Why Choose Us?</h2>
                            <div class="height-10"></div>
                            <p>Provides ISO 9001:2008, ISO 14001:2004, OHSAS 18001:2007, ISO 22000:2005 and HACCP Certification & CE Marking Services.</p>
                            <div class="height-10"></div>
                            <h3>OHSAS 18001</h3>
                            <p>Adaption of ohsas 18-001 should be an planned Decision of any Organization; Design & Implementation & time required is basically depend on the various factor.</p>
                            <h3>ISO 9001:2008</h3>
                            <p>ISO 9001:2008 helps Organisation to produce Desired Outcome and ISO 9001:2008 ensures Ongoing Controls. ISO 9001:2008 Enhance Customer Satisfaction by meeting Customer requirement.</p>
                            <h3>HACCP</h3>
                            <p>Schemes combines ISO 9000 with HACCP and certify as ISO 9001/HACCP. This scheme is in accordance with the principles of Codex Alimentarius in association with ISO 9000 series standards.</p>
                            <div class="height-10"></div>
                        </div>
                        <div class="col-md-6 animate fadeInRight">
                            <div class="video-widget">
                                <img src="<?php echo e(asset('assets/images/why.png')); ?>" class="img-shadow" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- / WELCOME -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>