<?php $__env->startSection('title', 'Certificate Search Results'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        
        <!--================Tracking Button Area =================-->
        <section class="tracking_search_area">
            <div class="container">
                <div class="tracking_search_inner">
                    <h2 class="single_title">Check Your Certificate Status</h2>
                    <h5>Enter a Certificate number, and get status results.</h5>
                    <form name="subscribe_form" action="<?php echo e(route('search')); ?>" method="POST">
							 <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                      <input type="text" name="certificate" class="form-control" placeholder="Certificate Number">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="fa fa-circle-o-notch" aria-hidden="true"></i> Get Status</button>
                      </span>
                    </div><!-- /input-group -->
                  </form>
                </div>
            </div>
        </section>
        <!--================End Tracking Button Area =================-->
        
        <!--================Tracking Timeline Area =================-->
        <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <section class="timeline_tracking_area">
            <div class="container">
                <div class="timeline_tracking_inner"> 
                    <div class="timeline_tracking_box">
                        <div class="tracking_head">
                            <h4><?php echo e($certificate->certificate_no); ?></h4>
                        </div>	
                        
                        <div class="tracking_in tag-delivered">
                            <h4><?php echo e($certificate->status); ?></h4>
                        </div>
                        <div class="tracking_in tag-delivered">
                            <table class="table table-bordered">	
                            	<thead>
                            		<tr>
                            			
                            		</tr>
                            	</thead>
                            </table>
                        </div> 
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<h2 class="text-danger text-center">Certificates not found!</h2>
				<?php endif; ?>  
            </div>
        </section>

        <!--================End Tracking Timeline Area =================-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>