<?php $__env->startSection('title', 'ISO 22000 Certification'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="subpage-header">
	<div class="container">
		<div class="site-title clearfix">
			<h2>Contact Us</h2>
			<ul class="breadcrumbs">
				<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
				<li>Contact Us</li>
			</ul>
		</div>
	</div>
</section>




<!-- CONTACT US -->
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6 animate fadeInLeft">
				<h3>Prudential Assessment Services LLP</h3>
				<div class="row">
					<div class="col-md-8 col-sm-8">
						<address>
							No:3, Ground Floor, Anjugam Nagar, Main Road, Jafferkhanpet, Chennai, Tamilnadu, India - 600083
						</address>
					</div>
				</div>
				<div class="height-20"></div>
				<h3>Follow Us</h3>
				<ul class="social">
					<li class="animate bounceIn"><a href="#." class="facebook"><i class="icon-facebook-1"></i></a></li>
					<li class="animate bounceIn" data-delay="100"><a href="#." class="twitter"><i class="icon-twitter-1"></i></a></li>
					<li class="animate bounceIn" data-delay="200"><a href="#." class="google-plus"><i class="icon-google"></i></a></li>
					<li class="animate bounceIn" data-delay="300"><a href="#." class="linkedin"><i class="icon-linkedin3"></i></a></li>
				</ul>
				<div class="height-50"></div>
				<div class="row">
						<p><i class="icon-telephone114"></i> +91 8939345355</p>
						<p><i class="icon-icons74"></i> info@prudentialiso.com</p>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 animate fadeInRight">
				<p class="success" id="success" style="display:none;"></p>
				<p class="error" id="error" style="display:none;"></p>
			
				<form class="contact-form" name="contact_form" id="contact_form" method="post" action="#" onSubmit="return false">
					<div class="row">
						<div class="col-md-6">
							<input type="text" data-delay="300" placeholder="Your full name" name="contact_name" id="contact_name" class="input">
						</div>
						<div class="col-md-6">
							<input type="text" data-delay="300" placeholder="E-mail Address" name="contact_email" id="contact_email" class="input">
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<input type="text" data-delay="300" placeholder="Phone No" name="contact_phone" id="contact_phone" class="input">
						</div>
					</div>
					<textarea data-delay="500" class="required valid" placeholder="Message" name="message" id="message"></textarea>
					<button class="btn btn-primary" name="" type="submit" data-text="Send Message" onClick="validateContact();">Send Message</button>
				</form>
			</div>
		</div>
	</div>
</section><!-- / COMPANY OVERVIEW -->

 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>