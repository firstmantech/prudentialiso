<?php $__env->startSection('title', 'CE Marking'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <section class="subpage-header">
				<div class="container">
					<div class="site-title clearfix">
						<h2>CE Marking</h2>
						<ul class="breadcrumbs">
							<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
							<li>CE Marking</li>
						</ul>
					</div>
					<a href="<?php echo e(url('contact')); ?>" class="btn btn-primary get-in-touch" data-text="Contact us"><i class="icon-telephone114"></i>Contact us</a>
				</div>
			</section>
            
            
			
			<!-- COMPANY OVERVIEW -->
            <section>
				<div class="container">
					<div class="row">
						<div class="col-md-12 animate fadeInLeft">
							<h2>What is CE Marking (CE Mark)?</h2>
							<div class="height-10"></div>
							<p>CE Marking is the symbol as shown on the top of this page. The letters “CE” are the abbreviation of French phrase “Conformité Européene” which literally means “European Conformity”. The term initially used was “EC Mark” and it was officially replaced by “CE Marking” in the Directive 93/68/EEC in 1993. “CE Marking” is now used in all EU official documents.
							</p>
						</div>
					</div>	

				
				</div>
			</section><!-- / COMPANY OVERVIEW -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>