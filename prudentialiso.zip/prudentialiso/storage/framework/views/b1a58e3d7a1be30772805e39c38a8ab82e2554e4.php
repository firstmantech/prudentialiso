<?php $__env->startSection('title', 'CE Marking'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--================Banner Area =================-->
    <section class="banner_area">
        <div class="container">
            <div class="pull-left">
                <h3>CE Marking</h3>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a>CE Marking</a>
            </div>
        </div>
    </section>
    <!--================End Banner Area =================-->
            
			
			<!-- COMPANY OVERVIEW -->
            <section class="price_faq_area">
				<div class="container">
					<div class="row">
						<div class="col-md-12 animate fadeInLeft">
							<h2>What is CE Marking (CE Mark)?</h2>
							<div class="height-10"></div>
							<p>CE Marking is the symbol as shown on the top of this page. The letters “CE” are the abbreviation of French phrase “Conformité Européene” which literally means “European Conformity”. The term initially used was “EC Mark” and it was officially replaced by “CE Marking” in the Directive 93/68/EEC in 1993. “CE Marking” is now used in all EU official documents.
							</p>
						</div>
					</div>	

				
				</div>
			</section><!-- / COMPANY OVERVIEW -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>