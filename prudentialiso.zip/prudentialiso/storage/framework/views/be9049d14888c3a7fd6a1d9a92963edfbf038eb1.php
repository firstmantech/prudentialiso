<?php $__env->startSection('title', 'Check Certificate Status'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <section class="subpage-header">
				<div class="container">
					<div class="col-md-6 col-md-offset-3">
						<div class="form">
							<form name="subscribe_form" action="<?php echo e(route('search')); ?>" method="POST">
							 <?php echo e(csrf_field()); ?>

								<input type="text" data-delay="300" placeholder="Certificate Number" name="certificate" id="certificate" class="input" required="">
								<div class="text-center">AND</div>
								<input type="text" data-delay="300" maxlength="3" placeholder="Enter First Three Letters of Company Name" name="company" id="company" class="input" required="">
								<button class="btn btn-primary" type="submit" name="certificate-form" data-text="Check Status">Check Status</button>
							</form>
						 </div>
					</div>					
				</div>
			</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>