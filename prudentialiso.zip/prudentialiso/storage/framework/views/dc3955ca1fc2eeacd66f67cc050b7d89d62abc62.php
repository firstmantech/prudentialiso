<?php $__env->startSection('title', 'Six Sigma'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <section class="subpage-header">
				<div class="container">
					<div class="site-title clearfix">
						<h2>Six Sigma</h2>
						<ul class="breadcrumbs">
							<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
							<li>Six Sigma</li>
						</ul>
					</div>
					<a href="<?php echo e(url('contact')); ?>" class="btn btn-primary get-in-touch" data-text="Contact us"><i class="icon-telephone114"></i>Contact us</a>
				</div>
			</section>
            
            
			
			<!-- COMPANY OVERVIEW -->
            <section>
				<div class="container">
					<div class="row">
						<div class="col-md-12 animate fadeInLeft">
							<h2>Six Sigma</h2>
							<div class="height-10"></div>
							<p>Keep your business processes lean and boost customer satisfaction with our Six Sigma & Lean training courses now aligned to ISO 13053 Quantitive methods in process improvement – Six Sigma.
							</p>
							<p>Spanning all areas of your business and all levels of expertise, our training is delivered by qualified tutors who support you all the way to national six sigma black belt status. Here, we offer a unique solution which tailors Six Sigma training around either manufacturing or service sectors, ensuring that the right results are achieved for you and your organization. In addition, both our Green and Black Belt training programmes include free certification.</p>				
						</div>
					</div>			
				</div>
			</section><!-- / COMPANY OVERVIEW -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>