<?php $__env->startSection('title', 'Food Safety'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <section class="subpage-header">
				<div class="container">
					<div class="site-title clearfix">
						<h2>Food Safety</h2>
						<ul class="breadcrumbs">
							<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
							<li>Food Safety</li>
						</ul>
					</div>
					<a href="<?php echo e(url('contact')); ?>" class="btn btn-primary get-in-touch" data-text="Contact us"><i class="icon-telephone114"></i>Contact us</a>
				</div>
			</section>
            
            
			
			<!-- COMPANY OVERVIEW -->
            <section>
				<div class="container">
					<div class="row">
						<div class="col-md-12 animate fadeInLeft">
							<h2>Food Safety</h2>
							<div class="height-10"></div>
							<p>This International Standard ISO 22000 specifies requirements for a food safety management system where an organization in the food chain needs to demonstrate its ability to control food safety hazards in order to ensure that food is safe at the time of human consumption. It is applicable to all organizations, regardless of size. The Hazard Analysis Critical Control Points or HACCP will be monitored closer by the QMS.
							</p>
											
						</div>
					</div>
									
				</div>
			</section><!-- / COMPANY OVERVIEW -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>